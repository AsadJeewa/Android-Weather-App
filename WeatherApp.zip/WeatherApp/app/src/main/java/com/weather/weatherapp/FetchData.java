package com.weather.weatherapp;

/**
 * Created by ferra on 2017/08/10.
 */

import android.content.Context;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class FetchData {

    public static final String OPEN_WEATHER_MAP_API =
//            "http://api.openweathermap.org/data/2.5/weather?q=%s&units=metric";
           "http://api.openweathermap.org/data/2.5/forecast/daily?lat="+WeatherActivity.lat+"&lon="+WeatherActivity.longi+"&units=metric";//&APPID=2cf7d0a12ebf5fa200acae3a3fe307de");//+R.string.apiKey);
    public static JSONObject getForecast(Context context){//get forecast
        try {
//            URL url = new URL(String.format(OPEN_WEATHER_MAP_API, city));
            URL url = new URL("http://api.openweathermap.org/data/2.5/forecast/daily?lat="+WeatherActivity.lat+"&lon="+WeatherActivity.longi+"&units=metric");//&APPID=2cf7d0a12ebf5fa200acae3a3fe307de");//+R.string.apiKey);

            HttpURLConnection connection =
                    (HttpURLConnection)url.openConnection();

            connection.addRequestProperty("x-api-key",
                    context.getString(R.string.apiKey));

            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(connection.getInputStream()));

            StringBuffer json = new StringBuffer(1024);
            String tmp="";
            while((tmp=reader.readLine())!=null)
                json.append(tmp).append("\n");
            reader.close();

            JSONObject data = new JSONObject(json.toString());

            // This value will be 404 if the request was not
            // successful
            if(data.getInt("cod") != 200){
                return null;
            }

            return data;
        }catch(Exception e){
            return null;
        }
    }

    public static JSONObject getWeather(Context context, String city){//get current weather
        try {
            URL url = new URL(String.format(OPEN_WEATHER_MAP_API, city));
//            URL url = new URL("http://api.openweathermap.org/data/2.5/forecast/daily?q="+city+"&units=metric");//&APPID=2cf7d0a12ebf5fa200acae3a3fe307de");//+R.string.apiKey);

            HttpURLConnection connection =
                    (HttpURLConnection)url.openConnection();

            connection.addRequestProperty("x-api-key",
                    context.getString(R.string.apiKey));

            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(connection.getInputStream()));

            StringBuffer json = new StringBuffer(1024);
            String tmp="";
            while((tmp=reader.readLine())!=null)
                json.append(tmp).append("\n");
            reader.close();

            JSONObject data = new JSONObject(json.toString());

            // This value will be 404 if the request was not
            // successful
            if(data.getInt("cod") != 200){
                return null;
            }

            return data;
        }catch(Exception e){
            return null;
        }
    }
}
