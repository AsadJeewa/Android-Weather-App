package com.weather.weatherapp;

import android.graphics.Typeface;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

public class WeatherFragment extends Fragment {
    Typeface weatherFont;

    TextView cityField;
    TextView updateField;
    TextView detailsField;
    TextView maxTempField;
    TextView minTempField;
    ImageView weatherIcon;


    Location loc;
    Handler handler;

    public WeatherFragment() {
        handler = new Handler();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_weather, container, false);
        cityField = (TextView) rootView.findViewById(R.id.cityField);
        updateField = (TextView) rootView.findViewById(R.id.lastUpdatedField);
        detailsField = (TextView) rootView.findViewById(R.id.detailsField);
        maxTempField = (TextView) rootView.findViewById(R.id.maxTemperatureField);
        minTempField = (TextView) rootView.findViewById(R.id.minTemperatureField);
        weatherIcon = (ImageView) rootView.findViewById(R.id.weatherIcon);
        return rootView;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        weatherFont = Typeface.createFromAsset(getActivity().getAssets(), "fonts/weather.ttf");
        if(WeatherActivity.success==true) {
            updateWeatherData();
        }
    }

    private void updateWeatherData() {
        new Thread() {
            public void run() {
                final JSONObject json = FetchData.getForecast(getActivity());
                if (json == null) {
                    handler.post(new Runnable() {
                        public void run() {
                            Toast.makeText(getActivity(),
                                    getActivity().getString(R.string.placeNotFound),
                                    Toast.LENGTH_LONG).show();
                        }
                    });
                } else {
                    handler.post(new Runnable() {
                        public void run() {
                            renderWeather(json);
                        }
                    });
                }
            }
        }.start();
    }

    private void renderWeather(JSONObject json) {//get weather data from json
        try {
            String currentDateTimeString = DateFormat.getDateTimeInstance().format(new Date());
            updateField.setText("Last Updated: "+currentDateTimeString);

            JSONObject city = json.getJSONObject("city");
            cityField.setText(city.getString("name").toUpperCase(Locale.US) +
                    ", " +
                    city.getString("country"));
            JSONObject temp = json.getJSONArray("list").getJSONObject(0).getJSONObject("temp");
            maxTempField.setText(String.format("Max: %.0f", temp.getDouble("max")) + "°C");
            minTempField.setText(String.format("Min: %.0f", temp.getDouble("min")) + "°C");
            JSONArray weather = json.getJSONArray("list").getJSONObject(0).getJSONArray("weather");
            detailsField.setText(weather.getJSONObject(0).getString("description") + "\nHumidity: " + json.getJSONArray("list").getJSONObject(0).getString("humidity") + "%"
                    + "\nWind Speed: " + json.getJSONArray("list").getJSONObject(0).getString("speed") + " m/s"+
                    "\nCloud Cover: " + json.getJSONArray("list").getJSONObject(0).getString("clouds") + "%");

            temp = json.getJSONArray("list").getJSONObject(1).getJSONObject("temp");
            detailsField.append(String.format("\n\nTomorrow's Forecast:\nMax:°C %.0f Min: %.0f°C",temp.getDouble("max"),temp.getDouble("min"))
                    +"\n"+json.getJSONArray("list").getJSONObject(1).getJSONArray("weather").getJSONObject(0).getString("description") );
            String icon = weather.getJSONObject(0).getString("icon");
            String iconUrl = "http://openweathermap.org/img/w/" + icon + ".png";
            Picasso.with(weatherIcon.getContext()).load(iconUrl).into(weatherIcon);
        }catch(Exception e){
            Log.e("SimpleWeather", "One or more fields not found in the JSON data");
        }
     }


//    private void setWeatherIcon(int actualId, long sunrise, long sunset){
//        int id = actualId / 100;
//        String icon = "";
//        if(actualId == 800){
//            long currentTime = new Date().getTime();
//            if(currentTime>=sunrise && currentTime<sunset) {
//                icon = getActivity().getString(R.string.sunny);
//            } else {
//                icon = getActivity().getString(R.string.clearNight);
//            }
//            icon = getActivity().getString(R.string.clearNight);
//        } else {
//            switch(id) {
//                case 2 : icon = getActivity().getString(R.string.thunder);
//                    break;
//                case 3 : icon = getActivity().getString(R.string.drizzle);
//                    break;
//                case 7 : icon = getActivity().getString(R.string.foggy);
//                    break;
//                case 8 : icon = getActivity().getString(R.string.cloudy);
//                    break;
//                case 6 : icon = getActivity().getString(R.string.snowy);
//                    break;
//                case 5 : icon = getActivity().getString(R.string.rainy);
//                    detailsField.append(icon);
//                    break;
//                default: icon = getActivity().getString(R.string.rainy);
//            }
//        }
//        weatherIcon2.setText(icon);
//    }
}

